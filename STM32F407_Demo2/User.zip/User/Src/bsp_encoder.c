//
// Created by lynliam on 23-4-8.
//
#include "bsp_encoder.h"

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim==&htim6)
    {
        motor_pid_control(&motor[0]);
        motor_pid_control(&motor[1]);
        motor_pid_control(&motor[2]);
        motor_pid_control(&motor[3]);
    }
    /*
    else if(htim==&(motor[0].TIM_EncoderHandle))
    {
        if(__HAL_TIM_IS_TIM_COUNTING_DOWN(&htim2))
            motor[0].motor_overflow_counter.Encoder_Overflow_Count--;
        else
            motor[0].motor_overflow_counter.Encoder_Overflow_Count++;
    }
     */
    //printf("%f,%f,%d,%f,%ld\n",motor[1].motor_pid.target,motor[1].motor_pid.fdb,motor[1].dutyfactor,motor[1].actual_speed,motor[1].motor_overflow_counter.Capture_Count);
}
