#ifndef __BSP_LED_H_
#define __BSP_LED_H_

#include "stm32f4xx.h"

#define KEY_ON        1;
#define KEY_OFF       0;


/*
void KEY_GPIOA_Init();
uint8_t Key_Scan(GPIO_TypeDef  *GPIOx, uint16_t GPIO_Pin);
 */
#endif

