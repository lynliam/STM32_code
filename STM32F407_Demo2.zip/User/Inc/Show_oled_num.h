//
// Created by lynliam on 23-7-4.
//

#ifndef STM32F407_DEMO2_SHOW_OLED_NUM_H
#define STM32F407_DEMO2_SHOW_OLED_NUM_H

#include "main.h"
#include "oled.h"
#include "My_spi.h"
#include "motor_control.h"

void draw_speed(motor_data *motor_);
#endif //STM32F407_DEMO2_SHOW_OLED_NUM_H
