//
// Created by lynliam on 23-7-3.
//

#ifndef STM32F407_DEMO2_BSP_BEEP_H
#define STM32F407_DEMO2_BSP_BEEP_H

#include "stm32f4xx.h"

void start_beep();

void wait_for_ps2_red();


#endif //STM32F407_DEMO2_BSP_BEEP_H
